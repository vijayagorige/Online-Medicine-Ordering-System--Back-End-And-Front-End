package com.medicine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MedicineOrderingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
